﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace serial
{
    public partial class Drawer : Form
    {
        //自己定义
        //X_Unit_length X_offset 需要同时更改为同一个数值

        private const int X_Unit_length = 24;                                     //X轴单位格大小
        private const int X_Num_Line = 16;                                        //X轴分段数目
        private const int X_offset = 24;                                          //X轴偏移 用于显示数字
        private const int X_Max_Limit = 256;                                     //单片机最大的数据不能超过0XFF
        private int X_Max = 256;                                                  //单片机最大的数据不能超过0XFF

        private const int Y_Unit_length = 24;                                     //Y轴单位格大小
        private const int Y_Num_Line = 32;                                        //Y轴分段数目
        private const int Y_offset = 24;                                          //X轴偏移 用于显示数字
        private const int Y_Max_Limit = 256;                                     //单片机最大的数据不能超过0XFF
        private int Y_Max = 256;                                                  //Y轴最大数值

        private const int StepValue = 4;                                         //步进值

        private List<byte> DataList = new List<byte>();                         //数据结构----线性链表
        private List<byte> DataList2 = new List<byte>();                         //数据结构----线性链表
        //显示多条曲线 需要在这里添加 线性链表 。。。

        private Pen TablePen = new Pen(Color.FromArgb(0xFF, 0xFF, 0xFF));       //轴线颜色
        private Pen LinesPen = new Pen(Color.FromArgb(0xA0, 0x00, 0x00));       //波形颜色
        private Pen LinesPen2 = new Pen(Color.FromArgb(0x00, 0xA0, 0x00));      //波形颜色
        //更改波形颜色 需要在这里添加  。。。

        public Drawer()
        {
            //开启双缓冲
            this.SetStyle(ControlStyles.DoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint,true);

            //更新双缓存
            this.UpdateStyles();

            InitializeComponent();
           
        }

        public void Auto_form_size()
        {
            this.Width = ((Y_Num_Line + 1) * Y_Unit_length) + 40;
            this.Height = ((X_Num_Line + 1) * X_Unit_length) + 60;
        }

        private void Drawer_Load(object sender, EventArgs e)
        {
            Auto_form_size();
        }

        public void AddData_First(byte[] Data_in, List<byte> Data_list)
        {
            for (int i = 0; i < Data_in.Length; i++)
            {
                Data_list.Add(Data_in[i]);
            }
        }

        //向线性链表尾部追加数据
        //Form1.cs被调用
        public void AddData(byte[] Data, byte[] Data2)
        {
            AddData_First(Data, DataList);
            AddData_First(Data2, DataList2);
            //显示多条曲线 需要在这里添加 数组 。。。

            Invalidate();//刷新显示
        }

        //画背景颜色
        public void Draw_BackGround(object sender, PaintEventArgs e)
        {
            e.Graphics.FillRectangle(Brushes.Black, X_offset, Y_offset, Y_Num_Line * Y_Unit_length, X_Num_Line * X_Unit_length);
        }

        public void Show_Paint_String(object sender, PaintEventArgs e)
        {
            //显示坐标系相关
            String str = " ";

            //2D图形显示
            System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();

            //打点
            TablePen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;

            if (X_Max > X_Max_Limit) X_Max = X_Max_Limit;

            //Draw Y 纵向轴绘制
            for (int i = 0; i < Y_Num_Line; i++)//多少条线
            {
                e.Graphics.DrawLine(TablePen, X_offset + X_Unit_length + i * X_Unit_length, Y_offset, X_offset + X_Unit_length + i * X_Unit_length, (X_Num_Line * X_Unit_length) + Y_offset);//画线
            }

            //底下显示内容
            for (int i = 0; i <= Y_Num_Line; i++)
            {
                str = (i * (Y_Max / Y_Num_Line)).ToString();
                gp.AddString(str, this.Font.FontFamily, (int)FontStyle.Italic, 12, new RectangleF((X_offset + i * X_Unit_length) - 8, (X_Num_Line * X_Unit_length) + Y_offset, 400, 20), null);//添加文字
            }

            //Draw X 横向轴绘制
            for (int i = 0; i < X_Num_Line; i++)
            {
                e.Graphics.DrawLine(TablePen, X_offset, Y_offset + Y_Unit_length + i * Y_Unit_length, X_offset + (Y_Unit_length * Y_Num_Line), Y_offset + Y_Unit_length + i * Y_Unit_length);
            }

            //底下显示内容
            for (int i = 0; i <= X_Num_Line; i++)
            {
                str = ((X_Num_Line - i) * (X_Max / X_Num_Line)).ToString();
                gp.AddString(str, this.Font.FontFamily, (int)FontStyle.Italic, 12, new RectangleF(0, (i * Y_Unit_length) + Y_offset - 6, 400, 20), null);//添加文字
            }

            //文字写入
            e.Graphics.DrawPath(Pens.Black, gp);
        }

        public void Collect_DataList(List<byte> Data)
        {
            int temp_len = 0;
            int temp_len2 = 0;

            temp_len = ((Y_Num_Line * Y_Unit_length)) / StepValue;
            temp_len2 = temp_len - 1;

            //如果数据量大于可容纳的数据量，即删除最左数据
            //曲线
            if (Data.Count - 1 >= temp_len)
            {
                Data.RemoveRange(0, Data.Count - temp_len2);
            }
        }

        //add_j 只能是 0 或是 1
        // 0 代表是前一个数据
        // 1代表是后一个数据
        public int Show_Collect_DataList_First(int i,int add_j,List<byte> Data)
        {
            int num_of_page = 0;
            int num_of_singe = 0;
            int temp = 0;

            int temp_1 = 0;
            int temp_2 = 0;

            temp_1 = (X_Num_Line * (X_Max / X_Num_Line));
            temp_2 = (X_Max / X_Num_Line);

            //收集链表信息
            Collect_DataList(Data);

            if (Data[i + add_j] >= temp_1)
            {
                Data[i + add_j] = (byte)temp_1;
                num_of_page = X_Num_Line;
                num_of_singe = 0;
            }
            else
            {
                num_of_page = Data[i + add_j] / temp_2;//得到整数部分
                num_of_singe = Data[i + add_j] % temp_2;//得到余数
            }

            temp = ((X_Num_Line + 1) * X_Unit_length) - (Y_offset * num_of_page + num_of_singe * (X_Unit_length / (X_Max / (X_Num_Line + 1))));

            return temp;
        }

        public void Show_Collect_DataList(object sender, PaintEventArgs e, Pen Pen_Color,List<byte> Data)
        {
            int temp = 0;
            int temp2 = 0;

            for (int i = 0; i < Data.Count - 1; i++)//绘制
            {
                temp = Show_Collect_DataList_First(i, 0, Data);
                temp2 = Show_Collect_DataList_First(i, 1, Data);


                //绘图
                e.Graphics.DrawLine(Pen_Color, Y_offset + i * StepValue, temp, Y_offset + (i + 1) * StepValue, temp2);
            }
        }


        //画格子，标数字
        //在 Dramer.Designer.cs 被调用

        /*以0-128为例                            对应坐标 (X轴) (每隔32个坐标为一行)
           |128_________________________________   Y_offset =32
           ...                                    ...
           |56___________________________________ ... 
           |48___________________________________ ...         
           |36___________________________________ 416
           |24___________________________________ 448
           |16___________________________________ 480
           |8___________________________________  (X_Num_Line + 1) * X_Unit_length) - Y_offset = 544 - 32 = 512
           |0___________________________________  (X_Num_Line + 1) * X_Unit_length) = （16+1）* 32 = 544
             
           具体坐标计算公式如下
           ((X_Num_Line + 1) * X_Unit_length) - (Y_offset * num_of_page + num_of_singe * (X_Unit_length / (X_Max / (X_Num_Line + 1))));
            */

        /*分情况讨论 存在问题
         (1) X_Max/X_Num_Line = 整数
         (2) X_Max/X_Num_Line = 有小数的 导致最后一个数计算错误（最大那个数）
         (3) 1024就不对
         */

        private void Form2_Paint(object sender, PaintEventArgs e)
        {
            byte[] temp = new byte[6];

            for(int i = 0;i<6;i++)
            {
                temp[i] = Form1.CHN_CURVE_SHOW[i];
            }

            //背景颜色
            Draw_BackGround(sender, e);

            //显示网格、字符串等相应信息
            Show_Paint_String(sender, e);

            //画相应曲线
            if (temp[0] == 1)
                Show_Collect_DataList(sender, e, LinesPen, DataList);

            if (temp[1] == 1)
                Show_Collect_DataList(sender, e, LinesPen2, DataList2);

            //添加曲线 需要在这里添加。。

            for (int i = 0; i < 6; i++)
            {
                temp[i] = 0;
            }

           }

        private void Drawer_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }
    }
}
